/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : STM32 Comunicaciones - PUENTE BIDIRECCIONAL Jetson <-> CAN
  *                   *** CON FRENO DE EMERGENCIA + ROBUSTEZ DE ENLACE ***
  *
  * Unico nodo que habla con la Jetson (USART2, 460800). Traduce en ambos
  * sentidos entre el UART de la Jetson y el bus CAN de las otras STM.
  *
  * ── SUBIDA (CAN -> UART -> Jetson) ──
  *   IMU:      0x100/0x101/0x102 -> CSV 10 campos "qw,...,az\r\n"
  *   Encoders: 0x200/0x201/0x202 -> CSV  9 campos "pos_L,...,u_R\n"
  *
  * ── BAJADA (Jetson -> UART -> CAN) ──
  *   "SP:<L>,<R>\n"  ->  CAN 0x300 con modo NORMAL (byte 4 = 0)
  *   "SP:BRAKE\n"    ->  CAN 0x300 con modo BRAKE  (byte 4 = 1)
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  ESTA REVISION: "LA PLACA DEJA DE RESPONDER DESPUES DE UN RATO"
  * ══════════════════════════════════════════════════════════════════════════
  *
  *  ★ 1. EL LED YA NO MENTIA, PERO TAMPOCO DECIA LA VERDAD
  *
  *     El LED estaba DENTRO de `if (imu_ready)`, o sea que parpadeaba solo
  *     cuando llegaban tramas CAN de la IMU. "El LED dejo de encender" NO
  *     significaba que el micro estuviera colgado: significaba que dejaron
  *     de llegar tramas. Son dos fallas completamente distintas y no habia
  *     forma de distinguirlas.
  *
  *     Ahora el LED lo maneja el SysTick, que corre pase lo que pase, con
  *     patrones distintos por estado (ver tabla abajo). Con esto:
  *
  *        LED APAGADO o FIJO = el micro esta muerto de verdad.
  *
  *     Ese solo cambio convierte una sesion de adivinanzas en un diagnostico
  *     de tres segundos.
  *
  *  ★ 2. AutoBusOff estaba en DISABLE  <- SOSPECHOSO PRINCIPAL
  *
  *     Con ABOM deshabilitado, si el controlador CAN entra en bus-off SE
  *     QUEDA AHI PARA SIEMPRE: no RX, no TX, sin recuperacion posible salvo
  *     cortar la energia. Los sintomas encajan al 100% con lo reportado:
  *     deja de llegar IMU (LED apagado), deja de salir telemetria, dejan de
  *     pasar los comandos. Y hay historial de errores LEC=3 por terminacion
  *     marginal (tres SN65HVD230 = 40 ohm, bajo el minimo de 45).
  *
  *     Se habilita ABOM en can.c Y ADEMAS se agrega recuperacion explicita
  *     aqui, porque ABOM solo cubre el bus-off, no una FIFO trabada ni una
  *     notificacion perdida.
  *
  *  ★ 3. NO HABIA HAL_UART_ErrorCallback  <- FALLA PERMANENTE SILENCIOSA
  *
  *     Con RX por interrupcion de un byte, si ocurre un overrun (ORE) el HAL
  *     llama a UART_EndRxTransfer(), deja RxState=READY y DESARMA la
  *     recepcion. El callback debil no hace nada, nadie vuelve a llamar
  *     HAL_UART_Receive_IT, y el RX muere PARA SIEMPRE. La placa sigue
  *     mandando telemetria (todo se ve normal) pero ya no acepta ni un
  *     comando mas. El rover se queda frenado "sin explicacion".
  *
  *  ★ 4. Y lo que hacia probable el punto 3: DEBUG_CMD llamaba a
  *     HAL_UART_Transmit BLOQUEANTE, con timeout de 20 ms, DENTRO de la ISR
  *     de RX, y el re-armado de Receive_IT estaba DESPUES. Durante esos ms
  *     se perdian bytes -> ORE -> muerte del RX. Y ocurria justo en el
  *     cambio de modo, es decir EN EL PARO DE EMERGENCIA.
  *     DEBUG_CMD ahora es 0 y el transmit salio de la ISR.
  *
  *  ★ 5. snprintf: se usaba el valor de retorno como longitud de transmision.
  *     snprintf devuelve lo que HABRIA escrito, no lo que cabe. Con el buffer
  *     de IMU en 96 bytes y 10 campos %.4f, en el peor caso se transmitian
  *     bytes de la pila mas alla del buffer. Ahora va acotado.
  *
  *  ★ 6. IWDG (~1.5 s) + handlers de fallo que RESETEAN.
  *     Antes Error_Handler y todos los *_Handler de excepcion eran
  *     while(1) infinitos: muerte total y silenciosa. Ahora cualquier
  *     cuelgue se recupera solo en menos de 2 s.
  *
  *     IMPORTANTE: un reset del target NO tira el VCP del ST-Link, asi que
  *     /dev/ttyACM* sobrevive y el bridge de ROS solo ve un hueco en la
  *     telemetria. La recuperacion es transparente.
  *
  *     OJO: el IWDG NO salva del bus-off (el bucle principal sigue corriendo
  *     feliz y sigue pateando al perro). Por eso el punto 2 es un arreglo
  *     independiente y necesario.
  *
  *  ★ 7. Diagnostico persistente: al arrancar se reporta la CAUSA DEL RESET
  *     leyendo RCC_CSR, y periodicamente los contadores de error del CAN.
  *     La proxima vez que falle, la respuesta estara en el log en vez de
  *     tener que reproducirlo.
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  PATRONES DEL LED (un solo LED, LD2)
  * ══════════════════════════════════════════════════════════════════════════
  *   Parpadeo LENTO  (1 s)     -> Todo sano: micro vivo + tramas CAN llegando
  *   Parpadeo RAPIDO (200 ms)  -> Micro vivo pero CAN MUDO (no llegan tramas)
  *   Parpadeo MUY RAPIDO(100ms)-> Bus-off detectado, intentando recuperar
  *   APAGADO o FIJO            -> El micro esta muerto. Ahora es inequivoco.
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  LINEAS DE DIAGNOSTICO EN EL UART
  * ══════════════════════════════════════════════════════════════════════════
  *  Empiezan con '#' y NO llevan comas, asi que tienen 1 solo campo y el
  *  rover_comms_bridge las descarta (discrimina por numero de campos: 9 =
  *  encoders, 10 = IMU). Se pueden ver con `cat` sin romper nada.
  *
  *      #BOOT rst=IWDG            <- causa del ultimo reset
  *      #CAN tec=0 rec=0 lec=0 bof=0 rx=1234
  *      #CAN RECOVER              <- se ejecuto recuperacion del bus
  *      #UART ERR n=3             <- se recupero de un overrun
  *
  *  Como leer #BOOT:
  *      rst=POR   -> arranque normal por energia. Esperado.
  *      rst=IWDG  -> EL MICRO SE COLGO y el watchdog lo revivio.  <-- ojo
  *      rst=SW    -> hubo un hard fault / Error_Handler.          <-- ojo
  *      rst=BOR   -> caida de voltaje. Problema de alimentacion.  <-- ojo
  *      rst=PIN   -> boton de reset o el ST-Link.
  *
  *  Si despues de una corrida ves rst=IWDG o rst=SW, ahi esta tu respuesta.
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  PPR DUPLICADO — mantener sincronizado a mano
  * ══════════════════════════════════════════════════════════════════════════
  *  Aqui el PPR solo convierte conteos a grados (pos_L/pos_R del CSV). Las
  *  velocidades las calcula el chasis con SU propio PPR. Si cambias el valor
  *  alla, cambialo TAMBIEN aqui o la posicion reportada saldra desfasada.
  *
  * NVIC necesarios (CubeMX -> NVIC Settings):
  *   - CAN1 RX0 interrupt       (recibir IMU/encoders del bus)
  *   - USART2 global interrupt  (recibir los SP: de la Jetson)
  *
  * ARCHIVOS QUE ACOMPANAN A ESTE:
  *   - can.c   : AutoBusOff = ENABLE
  *   - stm32f4xx_it.c : llamada a Heartbeat_Tick() y handlers que resetean
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* PPR: DEBE coincidir con el del firmware del chasis. goBILDA 5203 con
 * cuadratura = 753.2 * 4 = 3012.8. Si lo cambias alla, cambialo aqui. */
#define PPR   3012.8f
#define DT    0.014f
#define CAN_ID_CMD  0x300      /* comandos hacia el chasis */

/* Modos que viajan en el byte 4 de la trama 0x300 */
#define CMD_MODE_NORMAL   0    /* persigue los setpoints con el PID */
#define CMD_MODE_BRAKE    1    /* freno activo, ignora los setpoints */

/* CAMBIO: era 1. El debug llamaba a un Transmit BLOQUEANTE dentro de la ISR
 * de RX, provocando perdida de bytes y overrun justo en el paro de
 * emergencia. Ademas el transmit ya no vive en la ISR (ver ★4).
 * Ponerlo en 1 vuelve a imprimir BRAKE ON/OFF, pero ahora desde el bucle
 * principal, que es seguro. */
#define DEBUG_CMD   0

/* Perro guardian. Ponlo en 0 SOLO para depurar con breakpoints: con el IWDG
 * activo, detener el micro en el debugger provoca un reset. */
#define ENABLE_IWDG 1

/* Sin tramas CAN por mas de esto -> se considera el bus mudo y se intenta
 * recuperar. 1.5 s es holgado: la IMU manda a 100 Hz y los encoders a ~71 Hz,
 * asi que en operacion normal nunca pasa ni de 50 ms sin trama. */
#define CAN_SILENCE_MS   1500

/* Cada cuanto se reporta la linea de diagnostico del CAN */
#define CAN_REPORT_MS    5000

/* Periodos del LED en ms (medio periodo: cada cuanto hace toggle) */
#define LED_MS_OK        500   /* parpadeo lento     = todo sano          */
#define LED_MS_NOCAN     100   /* parpadeo rapido    = CAN mudo           */
#define LED_MS_BUSOFF     50   /* muy rapido         = bus-off recuperando*/
/* USER CODE END PD */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* ── IMU ── */
volatile float q_w = 1.0f, q_x = 0.0f, q_y = 0.0f, q_z = 0.0f;
volatile float gyro_x = 0.0f, gyro_y = 0.0f, gyro_z = 0.0f;
volatile float accel_x = 0.0f, accel_y = 0.0f, accel_z = 0.0f;
volatile uint8_t imu_msg_mask = 0;
#define IMU_MASK_COMPLETE 0x07
volatile uint8_t imu_ready = 0;

/* ── Encoders ── */
volatile int32_t enc_cnt_L = 0, enc_cnt_R = 0;
volatile float   enc_vel_L = 0.0f, enc_vel_R = 0.0f;
volatile float   enc_sp_L  = 0.0f, enc_sp_R  = 0.0f;
volatile float   enc_u_L   = 0.0f, enc_u_R   = 0.0f;
volatile uint8_t enc_msg_mask = 0;
#define ENC_MASK_COMPLETE 0x07
volatile uint8_t enc_ready = 0;
volatile float   enc_t = 0.0f;

/* Buffers CAN */
CAN_RxHeaderTypeDef rx_header;
uint8_t             rx_data[8];
static CAN_TxHeaderTypeDef can_tx_header;   /* para 0x300 */
static uint32_t            can_tx_mailbox;

/* ── UART RX: comandos "SP:L,R" / "SP:BRAKE" desde la Jetson ── */
uint8_t rx_byte = 0;
char    cmd_buf[32];
uint8_t cmd_idx = 0;

/* Ultimo modo reenviado. Solo para el debug opcional. */
static volatile uint8_t last_mode      = CMD_MODE_NORMAL;
static volatile uint8_t mode_changed   = 0;   /* bandera: imprime el bucle */

/* ── NUEVO: salud del enlace ── */
volatile uint32_t can_rx_count   = 0;   /* tramas CAN recibidas (total)   */
volatile uint32_t can_last_rx_ms = 0;   /* tick de la ultima trama        */
volatile uint32_t uart_err_count = 0;   /* overruns recuperados           */
volatile uint32_t can_recover_count = 0;/* recuperaciones ejecutadas      */

/* ── NUEVO: heartbeat del LED, manejado por SysTick ── */
/* volatile porque lo escribe el bucle y lo lee la interrupcion */
volatile uint16_t led_period_ms = LED_MS_OK;

/* Watchdog independiente */

/* Causa del reset, capturada antes de limpiar los flags */
static char reset_cause[8] = "?";

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void CAN_Filter_Config(void);
static void CAN_SendCmd(float sp_L, float sp_R, uint8_t mode);
static void CAN_Setup(void);
static void CAN_Recover(void);
static void Capture_Reset_Cause(void);
static void Diag_Print(const char *s);
void        Heartbeat_Tick(void);      /* la llama SysTick_Handler */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

static inline int16_t rd_i16(const uint8_t *b)
{
    return (int16_t)((uint16_t)b[0] | ((uint16_t)b[1] << 8));
}
static inline int32_t rd_i32(const uint8_t *b)
{
    return (int32_t)((uint32_t)b[0]        | ((uint32_t)b[1] << 8) |
                    ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24));
}

/* ══════════════════════════════════════════════════════════════════════════
 *  HEARTBEAT DEL LED  —  la llama SysTick_Handler cada 1 ms
 * ══════════════════════════════════════════════════════════════════════════
 *  Vive en la interrupcion del sistema, no en el bucle principal ni en el
 *  callback del CAN. Mientras el micro este vivo, ESTO PARPADEA. Si el LED
 *  se apaga o se queda fijo, el micro murio: no hay ambiguedad posible.
 *
 *  Se mantiene deliberadamente trivial (un contador y un toggle). Cualquier
 *  cosa mas pesada aqui se ejecutaria 1000 veces por segundo.
 */
void Heartbeat_Tick(void)
{
    static uint16_t c = 0;
    if (++c >= led_period_ms) {
        c = 0;
        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
    }
}

/* ==== CAN RX: IMU + encoders (subida) ==== */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) != HAL_OK)
        return;

    /* Marcas de vida del bus: las usa el vigilante del bucle principal. */
    can_rx_count++;
    can_last_rx_ms = HAL_GetTick();

    switch (rx_header.StdId)
    {
        case 0x100:
            q_w = rd_i16(&rx_data[0]) / 16384.0f;
            q_x = rd_i16(&rx_data[2]) / 16384.0f;
            q_y = rd_i16(&rx_data[4]) / 16384.0f;
            q_z = rd_i16(&rx_data[6]) / 16384.0f;
            imu_msg_mask = (1 << 0);   /* resincroniza el grupo */
            break;
        case 0x101:
            gyro_x = rd_i16(&rx_data[0]) / 1000.0f;
            gyro_y = rd_i16(&rx_data[2]) / 1000.0f;
            gyro_z = rd_i16(&rx_data[4]) / 1000.0f;
            imu_msg_mask |= (1 << 1);
            break;
        case 0x102:
            accel_x = rd_i16(&rx_data[0]) / 1000.0f;
            accel_y = rd_i16(&rx_data[2]) / 1000.0f;
            accel_z = rd_i16(&rx_data[4]) / 1000.0f;
            imu_msg_mask |= (1 << 2);
            break;

        case 0x200:
            enc_cnt_L = rd_i32(&rx_data[0]);
            enc_cnt_R = rd_i32(&rx_data[4]);
            enc_msg_mask = (1 << 0);
            break;
        case 0x201:
            enc_vel_L = rd_i16(&rx_data[0]) / 100.0f;
            enc_vel_R = rd_i16(&rx_data[2]) / 100.0f;
            enc_sp_L  = rd_i16(&rx_data[4]) / 100.0f;
            enc_sp_R  = rd_i16(&rx_data[6]) / 100.0f;
            enc_msg_mask |= (1 << 1);
            break;
        case 0x202:
            enc_u_L = (float)rd_i16(&rx_data[0]);
            enc_u_R = (float)rd_i16(&rx_data[2]);
            /* rx_data[4] trae flags del chasis (bit0 = frenando). Disponible
             * si algun dia se quiere reportar "FRENANDO" a la UI. */
            enc_msg_mask |= (1 << 2);
            break;

        default:
            break;
    }

    if (imu_msg_mask == IMU_MASK_COMPLETE) { imu_msg_mask = 0; imu_ready = 1; }
    if (enc_msg_mask == ENC_MASK_COMPLETE) { enc_msg_mask = 0; enc_t += DT; enc_ready = 1; }
}

/* ══════════════════════════════════════════════════════════════════════════
 *  ★ NUEVO: HAL_UART_ErrorCallback
 * ══════════════════════════════════════════════════════════════════════════
 *  Sin esta funcion, un solo overrun mataba el RX PARA SIEMPRE (ver ★3).
 *  Lo unico que hace falta es limpiar los flags y RE-ARMAR la recepcion.
 *
 *  La secuencia leer SR y luego DR es el modo canonico de limpiar
 *  ORE/NE/FE/PE en la F4. Se hace a mano ademas de la macro porque el
 *  nombre de la macro cambia entre versiones del HAL.
 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        volatile uint32_t tmp;
        tmp = huart->Instance->SR;
        tmp = huart->Instance->DR;
        (void)tmp;

        huart->ErrorCode = HAL_UART_ERROR_NONE;
        uart_err_count++;

        /* Descarta la linea a medias: viene corrupta por definicion. */
        cmd_idx = 0;

        HAL_UART_Receive_IT(huart, &rx_byte, 1);
    }
}

/* ==== UART RX: comandos de la Jetson -> CAN 0x300 ====
 * Acepta dos formatos:
 *     "SP:12.34,56.78"  -> setpoints normales
 *     "SP:BRAKE"        -> freno de emergencia
 *
 * El orden importa: hay que probar BRAKE ANTES de buscar la coma, porque
 * "SP:BRAKE" no tiene coma y caeria al descarte silencioso.
 *
 * ★ CAMBIO: aqui YA NO se transmite nada. Antes el debug llamaba a
 * HAL_UART_Transmit bloqueante (20 ms) dentro de esta ISR, con el
 * Receive_IT re-armandose DESPUES: durante ese tiempo se perdian bytes y
 * se provocaba el overrun del punto ★3. Ahora solo se levanta una bandera
 * y el bucle principal imprime. */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        if (rx_byte == '\n' || rx_byte == '\r')
        {
            if (cmd_idx > 0)
            {
                cmd_buf[cmd_idx] = '\0';
                if (strncmp(cmd_buf, "SP:", 3) == 0)
                {
                    /* ── FRENO DE EMERGENCIA ──────────────────────────── */
                    if (strncmp(cmd_buf + 3, "BRAKE", 5) == 0)
                    {
                        CAN_SendCmd(0.0f, 0.0f, CMD_MODE_BRAKE);
                        if (last_mode != CMD_MODE_BRAKE) mode_changed = 1;
                        last_mode = CMD_MODE_BRAKE;
                    }
                    /* ── SETPOINTS NORMALES ───────────────────────────── */
                    else
                    {
                        char *coma = strchr(cmd_buf + 3, ',');
                        if (coma != NULL)
                        {
                            *coma = '\0';
                            float sp_L = atof(cmd_buf + 3);
                            float sp_R = atof(coma + 1);
                            CAN_SendCmd(sp_L, sp_R, CMD_MODE_NORMAL);
                            if (last_mode != CMD_MODE_NORMAL) mode_changed = 1;
                            last_mode = CMD_MODE_NORMAL;
                        }
                    }
                }
                cmd_idx = 0;
            }
        }
        else if (cmd_idx < sizeof(cmd_buf) - 1)
        {
            cmd_buf[cmd_idx++] = rx_byte;
        }
        /* Si la linea excede el buffer los bytes extra se descartan y la
         * linea se parsea truncada. Es preferible a desbordar el arreglo. */

        HAL_UART_Receive_IT(&huart2, &rx_byte, 1);
    }
}

/* Filtro CAN: acepta todo (0x100-0x202 nos interesan; 0x300 lo mandamos
 * nosotros y no lo procesamos, pero no estorba). */
static void CAN_Filter_Config(void)
{
    CAN_FilterTypeDef filter;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = 0x0000;
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = 0x0000;
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14;
    HAL_CAN_ConfigFilter(&hcan1, &filter);
}

/* Arranque del CAN en un solo lugar, para poder repetirlo en la recuperacion. */
static void CAN_Setup(void)
{
    CAN_Filter_Config();
    HAL_CAN_Start(&hcan1);
    HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);
    can_last_rx_ms = HAL_GetTick();
}

/* ══════════════════════════════════════════════════════════════════════════
 *  ★ NUEVO: recuperacion del CAN
 * ══════════════════════════════════════════════════════════════════════════
 *  ABOM (habilitado en can.c) recupera el bus-off por hardware, pero NO
 *  cubre una FIFO trabada ni una notificacion perdida. Esta rutina reinicia
 *  el periferico completo, que si cubre los tres casos.
 *
 *  NOTA sobre el diagnostico: se decidio DETECTAR POR SONDEO del registro
 *  ESR en el bucle principal, en vez de habilitar la interrupcion CAN1_SCE.
 *  El motivo es practico: SCE exige tocar el NVIC en CubeMX y agregar un
 *  handler nuevo, y en este proyecto las omisiones de NVIC tras regenerar
 *  con CubeMX ya han costado varias sesiones. El sondeo no necesita nada.
 */
static void CAN_Recover(void)
{
    can_recover_count++;

    HAL_CAN_Stop(&hcan1);
    HAL_CAN_DeInit(&hcan1);
    MX_CAN1_Init();
    CAN_Setup();

    Diag_Print("#CAN RECOVER\r\n");
}

/* Imprime una linea de diagnostico. Empieza con '#' y no lleva comas, asi
 * que tiene 1 campo y el nodo de ROS la descarta sin ruido. */
static void Diag_Print(const char *s)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)s, (uint16_t)strlen(s), 20);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  ★ NUEVO: causa del ultimo reset
 * ══════════════════════════════════════════════════════════════════════════
 *  Hay que leerlo ANTES de limpiar los flags, y limpiarlos despues o el
 *  siguiente arranque reportaria lo mismo.
 *  El orden de las pruebas importa: IWDG y BOR se revisan antes que PIN
 *  porque suelen venir acompanados del flag de pin.
 */
static void Capture_Reset_Cause(void)
{
    if      (__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST)) strcpy(reset_cause, "IWDG");
    else if (__HAL_RCC_GET_FLAG(RCC_FLAG_SFTRST))  strcpy(reset_cause, "SW");
    else if (__HAL_RCC_GET_FLAG(RCC_FLAG_BORRST))  strcpy(reset_cause, "BOR");
    else if (__HAL_RCC_GET_FLAG(RCC_FLAG_PORRST))  strcpy(reset_cause, "POR");
    else if (__HAL_RCC_GET_FLAG(RCC_FLAG_PINRST))  strcpy(reset_cause, "PIN");
    else                                            strcpy(reset_cause, "?");

    __HAL_RCC_CLEAR_RESET_FLAGS();
}

int __io_putchar(int ch)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, 10);
    return ch;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();

  /* USER CODE BEGIN Init */
  /* Antes de tocar nada: por que arrancamos? */
  Capture_Reset_Cause();
  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_CAN1_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */
  CAN_Setup();

  /* Arrancar recepcion UART por interrupcion (comandos SP: de Jetson) */
  HAL_UART_Receive_IT(&huart2, &rx_byte, 1);

  /* Banner con la causa del reset. Esta es la linea que responde
   * "se colgo o se reinicio?" sin tener que reproducir la falla. */
  {
      char b[48];
      int n = snprintf(b, sizeof(b), "#BOOT rst=%s\r\n", reset_cause);
      if (n > 0) {
          if (n > (int)sizeof(b) - 1) n = (int)sizeof(b) - 1;
          HAL_UART_Transmit(&huart2, (uint8_t*)b, (uint16_t)n, 50);
      }
  }

#if ENABLE_IWDG
  /* IWDG: LSI ~32 kHz / 32 = 1 kHz -> recarga 1500 = ~1.5 s.
   * Cualquier cuelgue del bucle principal se recupera solo.
   * No salva del bus-off (el bucle sigue corriendo y sigue pateando al
   * perro); para eso esta CAN_Recover(). */
  	IWDG->KR  = 0x5555;
    IWDG->PR  = 3;
    IWDG->RLR = 1500;
    {
        uint32_t guard = 100000;
        while ((IWDG->SR != 0) && (--guard)) { __NOP(); }
    }
    IWDG->KR  = 0xAAAA;
    IWDG->KR  = 0xCCCC;
#endif
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint32_t last_report_ms = HAL_GetTick();

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

#if ENABLE_IWDG
    IWDG->KR = 0xAAAA;      /* patear al perro */
#endif

    uint32_t now = HAL_GetTick();

    /* ── Vigilancia del bus CAN ──────────────────────────────────────── */
    uint32_t esr    = hcan1.Instance->ESR;
    uint8_t  busoff = (esr & CAN_ESR_BOFF) ? 1 : 0;
    uint32_t silence = now - can_last_rx_ms;

    if (busoff) {
        led_period_ms = LED_MS_BUSOFF;
    } else if (silence > CAN_SILENCE_MS) {
        led_period_ms = LED_MS_NOCAN;
    } else {
        led_period_ms = LED_MS_OK;
    }

    /* Recuperar si el bus lleva mudo demasiado tiempo o entro en bus-off.
     * Se reintenta cada CAN_SILENCE_MS, no en cada vuelta del bucle. */
    if (busoff || silence > CAN_SILENCE_MS) {
        CAN_Recover();
        can_last_rx_ms = HAL_GetTick();   /* da tiempo antes del siguiente */
    }

    /* ── Reporte periodico de salud ──────────────────────────────────── */
    if (now - last_report_ms >= CAN_REPORT_MS) {
        last_report_ms = now;
        char b[96];
        int n = snprintf(b, sizeof(b),
            "#CAN tec=%lu rec=%lu lec=%lu bof=%u rx=%lu rec_n=%lu uerr=%lu\r\n",
            (unsigned long)((esr & CAN_ESR_TEC) >> CAN_ESR_TEC_Pos),
            (unsigned long)((esr & CAN_ESR_REC) >> CAN_ESR_REC_Pos),
            (unsigned long)((esr & CAN_ESR_LEC) >> CAN_ESR_LEC_Pos),
            busoff,
            (unsigned long)can_rx_count,
            (unsigned long)can_recover_count,
            (unsigned long)uart_err_count);
        if (n > 0) {
            if (n > (int)sizeof(b) - 1) n = (int)sizeof(b) - 1;
            HAL_UART_Transmit(&huart2, (uint8_t*)b, (uint16_t)n, 20);
        }
    }

#if DEBUG_CMD
    /* El debug ahora vive AQUI, no en la ISR. */
    if (mode_changed) {
        mode_changed = 0;
        Diag_Print(last_mode == CMD_MODE_BRAKE ? "#BRAKE ON\r\n" : "#BRAKE OFF\r\n");
    }
#endif

    /* ── CSV de IMU: 10 campos ── */
    if (imu_ready)
    {
        imu_ready = 0;
        char tx_buf[160];   /* CAMBIO: era 96, insuficiente en el peor caso */
        int len = snprintf(tx_buf, sizeof(tx_buf),
            "%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f\r\n",
            q_w, q_x, q_y, q_z, gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z);
        /* CAMBIO CRITICO: snprintf devuelve lo que HABRIA escrito. Sin este
         * acotamiento se transmitian bytes de la pila mas alla del buffer. */
        if (len > 0) {
            if (len > (int)sizeof(tx_buf) - 1) len = (int)sizeof(tx_buf) - 1;
            HAL_UART_Transmit(&huart2, (uint8_t*)tx_buf, (uint16_t)len, 20);
        }
    }

    /* ── CSV de encoders: 9 campos ── */
    if (enc_ready)
    {
        enc_ready = 0;
        float pos_L = ((float)enc_cnt_L / PPR) * 360.0f;
        float pos_R = ((float)enc_cnt_R / PPR) * 360.0f;
        char tx_buf[192];   /* CAMBIO: era 128. pos_L/pos_R y enc_t crecen
                             * sin limite con el tiempo de operacion, asi que
                             * la linea se alarga conforme corre el rover. */
        int len = snprintf(tx_buf, sizeof(tx_buf),
            "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n",
            (double)pos_L, (double)enc_vel_L, (double)pos_R, (double)enc_vel_R,
            (double)enc_t, (double)enc_sp_L, (double)enc_sp_R,
            (double)enc_u_L, (double)enc_u_R);
        if (len > 0) {
            if (len > (int)sizeof(tx_buf) - 1) len = (int)sizeof(tx_buf) - 1;
            HAL_UART_Transmit(&huart2, (uint8_t*)tx_buf, (uint16_t)len, 20);
        }
    }
    /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }

  /* NOTA PENDIENTE — HSE_ON vs HSE_BYPASS:
   * La Nucleo-F446RE alimenta el HSE desde el MCO del ST-Link, lo que en
   * rigor pide RCC_HSE_BYPASS. Con HSE_ON arranca (por eso funciona), pero
   * es un arranque marginal. Si algun dia el HSE se cae en operacion, el
   * micro se queda sin reloj y muere en silencio.
   *
   * NO se cambio aqui a proposito: si la placa lleva cristal poblado,
   * cambiarlo a BYPASS la dejaria sin arrancar, y no lo puedo verificar a
   * distancia. Es una prueba de banco de 2 minutos: cambiar a
   * RCC_HSE_BYPASS, flashear, y ver si el LED parpadea. Si parpadea, dejalo
   * asi Y cambia tambien el .ioc, o CubeMX lo revierte al regenerar. */
}

/* USER CODE BEGIN 4 */

/* ==== reenvia comandos por CAN al chasis (0x300) ====
 * setpoints en RPM -> int16 x100 little-endian, mas el byte de modo.
 *
 * DLC 5. El chasis nuevo lee el byte 4 si viene y asume NORMAL si no; un
 * chasis viejo ignora el byte extra. Se pueden actualizar en cualquier
 * orden sin romper nada. */
static void CAN_SendCmd(float sp_L, float sp_R, uint8_t mode)
{
    uint8_t data[5];
    int16_t l = (int16_t)(sp_L * 100.0f);
    int16_t r = (int16_t)(sp_R * 100.0f);

    data[0] = (uint8_t)(l & 0xFF);
    data[1] = (uint8_t)((l >> 8) & 0xFF);
    data[2] = (uint8_t)(r & 0xFF);
    data[3] = (uint8_t)((r >> 8) & 0xFF);
    data[4] = mode;

    can_tx_header.StdId = CAN_ID_CMD;
    can_tx_header.IDE   = CAN_ID_STD;
    can_tx_header.RTR   = CAN_RTR_DATA;
    can_tx_header.DLC   = 5;
    can_tx_header.TransmitGlobalTime = DISABLE;

    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0)
        HAL_CAN_AddTxMessage(&hcan1, &can_tx_header, data, &can_tx_mailbox);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * ★ CAMBIO: antes era __disable_irq() + while(1), o sea muerte total y
  * silenciosa con el LED apagado y sin recuperacion posible.
  * Ahora parpadea rapido un momento (para que se vea que paso algo) y
  * REINICIA. El flag SFTRST hara que el siguiente arranque reporte
  * "#BOOT rst=SW", que es tu pista de que hubo un fallo.
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();

  /* Parpadeo de agonia: ~1 s, visible pero corto. No se usa HAL_Delay
   * porque depende de SysTick y las interrupciones estan apagadas. */
  for (volatile uint32_t i = 0; i < 20; i++) {
      HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
      for (volatile uint32_t d = 0; d < 900000; d++) { __NOP(); }
  }

  NVIC_SystemReset();
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/*
 * ══════════════════════════════════════════════════════════════════════════
 *  PRUEBAS — en banco, solo esta placa y el cable USB. Sin rover.
 * ══════════════════════════════════════════════════════════════════════════
 *
 *  Deten el rover_comms_bridge para liberar el puerto y desde el host:
 *      stty -F /dev/ttyACM0 460800 raw -echo
 *      cat /dev/ttyACM0
 *
 *  ── P1. ARRANQUE ────────────────────────────────────────────────────────
 *     Debe salir "#BOOT rst=..." una sola vez.
 *     Si sale REPETIDAMENTE cada segundo y medio, el micro se esta
 *     reiniciando en bucle: el IWDG esta mordiendo porque algo cuelga el
 *     bucle principal. Pon ENABLE_IWDG en 0, reflashea, y busca el cuelgue.
 *
 *  ── P2. HEARTBEAT SIN CAN (la prueba clave) ─────────────────────────────
 *     Con el bus CAN DESCONECTADO (o las otras STM32 apagadas):
 *        ESPERADO: el LED parpadea RAPIDO (~200 ms) y salen lineas
 *                  "#CAN ... rx=0" cada 5 s.
 *        Esto es lo que antes era imposible de ver: el micro esta vivo
 *        aunque no llegue una sola trama. Antes el LED se quedaba apagado
 *        y parecia muerto.
 *
 *  ── P3. HEARTBEAT CON CAN ───────────────────────────────────────────────
 *     Conecta el bus y enciende la IMU:
 *        ESPERADO: el LED baja a parpadeo LENTO (~1 s), empiezan a salir
 *                  los CSV de 10 campos, y en las lineas #CAN el contador
 *                  rx= sube.
 *
 *  ── P4. RECUPERACION DEL BUS ────────────────────────────────────────────
 *     Con todo funcionando, DESCONECTA el cable CAN en caliente:
 *        ESPERADO: en ~1.5 s el LED pasa a rapido y sale "#CAN RECOVER".
 *     Vuelve a conectarlo:
 *        ESPERADO: el LED regresa a lento SOLO, sin resetear nada.
 *     Esta es la prueba que valida el arreglo del bus-off. Antes de este
 *     cambio, desconectar y reconectar dejaba la placa muda para siempre.
 *
 *  ── P5. RECUPERACION DEL UART ───────────────────────────────────────────
 *     Manda basura a alta velocidad para forzar overrun:
 *        for i in $(seq 1 500); do printf 'XXXXXXXXXXXXXXXXXXXX\n'; done \
 *            > /dev/ttyACM0
 *     Luego manda un comando normal:
 *        while true; do echo "SP:10,10" > /dev/ttyACM0; sleep 0.1; done
 *        ESPERADO: sigue respondiendo. En las lineas #CAN, uerr= puede
 *                  haber subido: eso significa que hubo overruns Y QUE SE
 *                  RECUPERO. Antes de este cambio el RX moria ahi mismo.
 *
 *  ── P6. FRENO (necesita el chasis) ──────────────────────────────────────
 *     while true; do echo "SP:30,30" > /dev/ttyACM0; sleep 0.1; done &
 *     sleep 3; echo "SP:BRAKE" > /dev/ttyACM0
 *        ESPERADO: los motores paran aunque el bucle siga mandando 30,30.
 *
 *  ── QUE GUARDAR ─────────────────────────────────────────────────────────
 *  Antes de salir a competencia, guarda el .bin de esta version funcionando
 *  y llevate el ST-Link. Poder revertir en dos minutos vale mas que
 *  cualquier mejora que se te ocurra el dia antes.
 * ══════════════════════════════════════════════════════════════════════════
 */
