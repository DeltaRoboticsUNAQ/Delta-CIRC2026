/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Skid-steer 6 ruedas — Encoders + PID + PWM  (100% CAN)
  *                   *** FRENO ACTIVO + MODO DEGRADADO DE ENCODERS ***
  *
  * ARQUITECTURA: el chasis no usa UART. Todo va por CAN:
  *   RECIBE  0x300 : setpoint_L, setpoint_R (int16 x100, RPM) + modo [byte 4]
  *   ENVIA   0x200 : cnt_L (int32), cnt_R (int32)            [conteos crudos]
  *           0x201 : vel_L, vel_R, sp_L, sp_R (int16 x100)   [RPM]
  *           0x202 : u_L, u_R (int16, -1000..1000) + flags   [byte 4]
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  ESTA REVISIÓN — QUE LOS MOTORES SIGAN SIRVIENDO SIN ENCODER
  * ══════════════════════════════════════════════════════════════════════════
  *
  *  EL PROBLEMA, CONCRETO
  *  ─────────────────────────────────────────────────────────────────────────
  *  El encoder derecho ha muerto varias veces en banco (cable flojo, 3.3 V
  *  ausente, GND suelto). Es una fragilidad conocida y con vibración de
  *  competencia va a volver a pasar.
  *
  *  Qué ocurre hoy cuando eso pasa: el error se queda clavado en +setpoint
  *  para siempre, y como el PID es incremental, `u` sube hasta el tope y SE
  *  QUEDA EN 1000. La rueda gira a fondo, sin regulación, hasta que alguien
  *  corta la energía. (El windup ya está acotado — `u_ant = u` después del
  *  clamp — así que no se dispara al infinito, pero queda pegado al máximo,
  *  que para efectos prácticos es lo mismo.)
  *
  *  ★ 1. DETECCIÓN DE ENCODER CAÍDO
  *
  *     Dos síntomas, ambos vigilados por lado sobre una ventana de ~300 ms:
  *
  *       a) MUERTO: se comanda movimiento (|sp| > 5 RPM), el PID está
  *          empujando fuerte (|u| > 800) y los conteos NO cambian.
  *          Si se pide girar y el micro empuja al 80% sin que el contador se
  *          mueva, el encoder no está leyendo. No hay otra explicación.
  *
  *       b) INVERTIDO: la velocidad medida sale con signo opuesto a la
  *          salida del control y |u| está alto. Eso es realimentación
  *          POSITIVA — el lazo se empuja a sí mismo hacia la saturación.
  *          Es exactamente el modo de falla de julio. Se trata igual que
  *          muerto: más vale lazo abierto que un lazo que se autoexcita.
  *
  *  ★ 2. CONTROL DEGRADADO EN LAZO ABIERTO
  *
  *     Al degradar: PID_Reset() y se pasa a feedforward, u = FF_GAIN·sp,
  *     con TOPE DURO al 60%. Sin encoder no sabes qué está pasando en esa
  *     rueda, así que no se le da velocidad plena.
  *
  *     FF_GAIN sale de la medición de banco: u≈377 sostenía 19 RPM, o sea
  *     ~19.8 unidades de PWM por RPM. Ver la nota de calibración abajo.
  *
  *     El rover queda manejable — no preciso, pero manejable. Que es la
  *     diferencia entre terminar la tarea y abandonarla.
  *
  *  ★ 3. EL FRENO TAMBIÉN ESTABA ROTO SIN ENCODER  <-- esto no lo habíamos visto
  *
  *     ApplyBrake() aplica par proporcional a la velocidad MEDIDA. Con el
  *     encoder muerto, velFilt vale 0, así que la función concluye "ya está
  *     detenida", suelta el par y deja la rueda EN LIBRE.
  *
  *     O sea: el paro de emergencia y el failsafe del watchdog NO FRENABAN
  *     el lado con encoder caído — justo el escenario que más importa.
  *
  *     Ahora, si el lado está degradado, se frena en lazo abierto: par en
  *     contra del ÚLTIMO SETPOINT conocido, a BRAKE_OL_DUTY, durante un
  *     máximo de BRAKE_OL_TICKS (~0.5 s) y después PWM 0. Acotado en tiempo
  *     a propósito: sin realimentación no hay forma de saber cuándo parar,
  *     y un par en contra indefinido invertiría el giro.
  *
  *  ★ 4. RECUPERACIÓN AUTOMÁTICA
  *
  *     Si el encoder vuelve (cable que hace contacto otra vez), se exige
  *     ~200 ms de conteos coherentes ANTES de volver a lazo cerrado, y se
  *     hace PID_Reset() en la transición para que no dé un tirón. La
  *     histéresis evita entrar y salir del modo con un cable intermitente.
  *
  *  ★ 5. TELEMETRÍA HONESTA
  *
  *     Antes 0x202 reportaba pid_L.u, que durante el freno vale 0 aunque se
  *     esté aplicando par. Ahora se reporta u_out_L/u_out_R: lo que de
  *     verdad se escribió al PWM, venga del PID, del freno o del lazo
  *     abierto.
  *
  *     Y el byte de flags crece:
  *         bit0 = frenando
  *         bit1 = lado IZQUIERDO degradado
  *         bit2 = lado DERECHO degradado
  *
  *     Esto NO rompe nada río arriba: la comms lee solo los primeros 4
  *     bytes de 0x202 y el DLC ya era 5. Cuando quieras mostrarlo en la UI,
  *     el dato ya está viajando.
  *
  *     ⚠️ NO se agregó ningún campo al CSV. El rover_comms_bridge
  *     discrimina los dos streams POR NÚMERO DE CAMPOS (9 = encoders,
  *     10 = IMU). Un décimo campo en el CSV de encoders haría que el nodo
  *     lo parseara como IMU. Por eso el estado viaja en el byte de flags
  *     del CAN y no en el CSV.
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  CALIBRACIÓN DE FF_GAIN — hazlo con las ruedas al aire
  * ══════════════════════════════════════════════════════════════════════════
  *  1. Comanda un setpoint medio (ej. SP:20,20) con AMBOS encoders sanos.
  *  2. Espera a que se estabilice y anota `u` y `vel` de /wheel_debug.
  *  3. FF_GAIN = u / vel
  *
  *  Repítelo a dos velocidades distintas (ej. 10 y 30 RPM). Si los dos
  *  cocientes salen parecidos, el modelo lineal basta. Si el de baja
  *  velocidad sale MUCHO más alto, hay fricción estática apreciable y
  *  conviene usar FF_OFFSET:
  *      FF_GAIN   = (u2 - u1) / (vel2 - vel1)
  *      FF_OFFSET = u1 - FF_GAIN·vel1
  *
  *  El valor que viene por defecto sale de una sola medición de banco
  *  (u≈377 a 19 RPM). Es un punto de partida razonable, no una calibración.
  *
  * ══════════════════════════════════════════════════════════════════════════
  *  CORRECCIONES ANTERIORES (siguen vigentes)
  * ══════════════════════════════════════════════════════════════════════════
  *  · El failsafe no servía: PID_Step corría siempre y pisaba el PWM que el
  *    failsafe acababa de poner en cero. Ahora frenar y controlar son ramas
  *    EXCLUYENTES.
  *  · ApplyPWM(0) deja los motores en rueda libre y el rover sigue de largo
  *    por inercia. ApplyBrake() aplica par en contra (plugging), que sí
  *    detiene. Es la red de seguridad más importante del sistema porque vive
  *    AQUÍ: funciona aunque se caiga el WiFi, la Jetson o el navegador.
  *  · Modo BRAKE por CAN (byte 4 de 0x300), enclavado hasta que llegue una
  *    trama NORMAL. Con DLC 4 se asume NORMAL (compatibilidad).
  *  · Kp y Ki en un solo lugar; Ti se recalcula solo.
  *
  *  AJUSTE DEL PID (ruedas al aire, con el corte de corriente a la mano):
  *    Sube KP_GAIN por escalones mirando /wheel_debug:
  *        1.0/7  →  2.0/12  →  3.5/16  →  5.0/20
  *    Detente al ver oscilación sostenida, zumbido, o u brincando entre
  *    extremos. Regresa un escalón y bájale 30%: ese margen es el seguro
  *    para cuando el rover lleve peso y vaya en tierra.
  *
  *  === MAPA DE TIMERS ===
  *  Encoders:  TIM4 (IZQ, 16-bit, PB6/PB7)   TIM8 (DER, 16-bit, PC6/PC7)
  *  Base ctrl: TIM5 (IRQ, 14 ms exactos)
  *  PWM 18kHz: TIM1 (DER) / TIM2 (DER CH1-2, IZQ CH3-4) / TIM3 (IZQ)
  *  CAN1:      PA12 (TX) / PB8 (RX)  -> SN65HVD230
  *
  *  NVIC: "CAN1 RX0 interrupt" habilitado en CubeMX. Sin eso el 0x300 nunca
  *  se procesa, el watchdog expira y el rover se queda frenado sin razón
  *  aparente.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define PPR           3012.8f      // goBILDA 5203 = 753.2*4 = 3012.8
#define DT            0.014f       // TIM5 = 14.0 ms exactos
#define CMD_TIMEOUT_TICKS  33      // ~0.46 s sin comando -> frena (failsafe)
#define N_MOT_PER_SIDE     3       // 3 motores por lado

#define CAN_ID_CMD    0x300        // comandos setpoint desde la comms

/* ── Modos que puede pedir la Jetson en el byte 4 de la trama 0x300 ────── */
#define CMD_MODE_NORMAL   0
#define CMD_MODE_BRAKE    1

/* ══════════════════════════════════════════════════════════════════════
 *  GANANCIAS DEL PI  —  AJUSTAR SOLO ESTAS DOS
 * ══════════════════════════════════════════════════════════════════════ */
#define KP_GAIN       1.0f
#define KI_GAIN       7.0f

/* ══════════════════════════════════════════════════════════════════════
 *  FRENO ACTIVO
 * ══════════════════════════════════════════════════════════════════════
 *  BRAKE_GAIN está en unidades de PWM por RPM medida. Con 30 y una rueda
 *  a 19 RPM da u = -570: un frenazo real, aplicado en UN ciclo de 14 ms.
 *  Si al frenar derrapa o se sacude, bájalo. Si tarda, súbelo (tope ~50).
 *
 *  BRAKE_EPS_RPM es la banda muerta: por debajo se considera detenido y se
 *  suelta el par, para que el motor no vibre persiguiendo ruido.          */
#define BRAKE_GAIN       30.0f
#define BRAKE_EPS_RPM     1.5f

/* ── Freno para un lado SIN encoder (ver ★3) ──────────────────────────
 *  Sin realimentación no se puede modular el par ni saber cuándo parar,
 *  así que se aplica un duty fijo en contra del último setpoint conocido,
 *  ACOTADO EN TIEMPO. Pasados los ticks se suelta: prolongarlo indefinido
 *  invertiría el giro de la rueda en lugar de detenerla.                  */
#define BRAKE_OL_DUTY    450.0f    /* ~45% de par en contra */
#define BRAKE_OL_TICKS      36     /* ~0.5 s a 14 ms        */

/* ══════════════════════════════════════════════════════════════════════
 *  MODO DEGRADADO — detección de encoder caído
 * ══════════════════════════════════════════════════════════════════════ */
/* Umbral de "se está pidiendo movimiento de verdad" */
#define DEG_SP_MIN_RPM     5.0f
/* |u| por encima de esto = el PID está empujando fuerte */
#define DEG_U_FAULT      800.0f
/* Ticks seguidos con el síntoma antes de declarar la falla (~300 ms) */
#define DEG_FAULT_TICKS     21
/* Ticks seguidos de lecturas sanas antes de volver a lazo cerrado (~200 ms) */
#define DEG_OK_TICKS        14
/* Velocidad mínima para creerle al signo de vel (evita ruido cerca de 0) */
#define DEG_VEL_MIN_RPM    1.0f

/* Feedforward del lazo abierto. VER LA NOTA DE CALIBRACIÓN EN EL ENCABEZADO. */
#define FF_GAIN          19.8f     /* unidades de PWM por RPM */
#define FF_OFFSET         0.0f     /* compensación de fricción estática */
/* Tope duro en degradado: sin encoder no sabes qué pasa, no des todo. */
#define DEG_MAX_U       600.0f

/* Telemetria por lado */
volatile float pos_L = 0.0f, vel_L = 0.0f, velFilt_L = 0.0f;
volatile float pos_R = 0.0f, vel_R = 0.0f, velFilt_R = 0.0f;
volatile float t = 0.0f;
volatile uint8_t flag_tim5 = 0;

/* Salida REALMENTE aplicada al PWM, venga de donde venga (PID, freno o
 * lazo abierto). Es lo que se reporta ahora en 0x202. */
volatile float u_out_L = 0.0f, u_out_R = 0.0f;

/* Contadores previos (ambos encoders 16 bits) */
uint16_t cnt_prev_L = 0;           // TIM4
uint16_t cnt_prev_R = 0;           // TIM8

/* Conteos acumulados de 32 bits (lo que viaja por CAN). */
volatile int32_t cnt_total_L = 0;
volatile int32_t cnt_total_R = 0;

/* Setpoints (RPM) — llegan por CAN 0x300 */
volatile float setpoint_L = 0.0f;
volatile float setpoint_R = 0.0f;
volatile uint16_t rx_watchdog = 0;

/* Modo pedido por la Jetson. Se mantiene hasta que llegue una trama NORMAL,
 * así el paro de emergencia queda enclavado aunque la Jetson deje de hablar. */
volatile uint8_t brake_request = 0;

/* Estado realmente aplicado en el último ciclo (para telemetría). */
volatile uint8_t braking_now = 0;

/* ── NUEVO: salud del encoder por lado ── */
typedef struct {
    uint8_t  degraded;      /* 1 = lazo abierto                       */
    uint16_t fault_ticks;   /* ticks seguidos con síntoma de falla     */
    uint16_t ok_ticks;      /* ticks seguidos con lecturas sanas       */
    int32_t  last_cnt;      /* conteo del tick anterior                */
    float    last_sp;       /* último setpoint distinto de cero        */
    uint16_t brake_ticks;   /* ticks restantes de freno en lazo abierto*/
} EncHealth_t;

volatile EncHealth_t health_L = {0};
volatile EncHealth_t health_R = {0};

/* PID incremental: ganancias compartidas, estado por lado */
const float Kp = KP_GAIN;
const float Ki = KI_GAIN;
const float Ti = KP_GAIN / KI_GAIN;
const float Td = 0.0f;
float q0, q1, q2;

typedef struct { float e0, e1, e2; float u, u_ant; } PID_t;
PID_t pid_L = {0};
PID_t pid_R = {0};

/* CAN */
static CAN_TxHeaderTypeDef can_tx_header;
static uint32_t            can_tx_mailbox;
static CAN_RxHeaderTypeDef can_rx_header;
static uint8_t             can_rx_data[8];

/* === Mapa de PWM por motor ===
 * Cada motor: { timer, canal de AVANCE (RPWM), canal de REVERSA (LPWM) }.
 * Para invertir el giro de una rueda se INTERCAMBIAN sus dos canales.
 *
 * REGLA DE ORO: el control es POR LADO (un encoder y un PID para las 3
 * ruedas del lado), así que invertir una rueda suelta NO afecta al lazo.
 * Pero si inviertes TODO un lado, hay que negar también el delta de SU
 * encoder más abajo, o el PID entra en realimentación positiva y satura.
 * (Síntoma: velocidad medida con signo opuesto al setpoint y u pegado en
 * ±1000. Nota: esa condición ahora la DETECTA el modo degradado y abre el
 * lazo, así que el rover no se descontrola — pero sigue siendo un error de
 * cableado que hay que corregir, no una función.) */
typedef struct {
    TIM_HandleTypeDef *htim;
    uint32_t ch_fwd;   // RPWM (avance)
    uint32_t ch_rev;   // LPWM (reversa)
} MotorPWM_t;

/* LADO DERECHO */
MotorPWM_t motors_R[N_MOT_PER_SIDE] = {
    { &htim1, TIM_CHANNEL_2, TIM_CHANNEL_1 },   // R frontal
    { &htim2, TIM_CHANNEL_2, TIM_CHANNEL_1 },   // R medio
    { &htim3, TIM_CHANNEL_2, TIM_CHANNEL_1 },   // R trasero
};

/* LADO IZQUIERDO */
MotorPWM_t motors_L[N_MOT_PER_SIDE] = {
    { &htim1, TIM_CHANNEL_3, TIM_CHANNEL_4 },   // L frontal
    { &htim2, TIM_CHANNEL_3, TIM_CHANNEL_4 },   // L medio
    { &htim3, TIM_CHANNEL_3, TIM_CHANNEL_4 },   // L trasero
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void PID_Init(void);
static void PID_Reset(PID_t *pid);
static void ApplyPWM(MotorPWM_t *m, uint8_t n, float u);
static void ApplyBrake(MotorPWM_t *m, uint8_t n, float rpm_med, float *u_rep);
static void ApplyBrakeOpenLoop(volatile EncHealth_t *h, MotorPWM_t *m,
                               uint8_t n, float *u_rep);
static void ApplyOpenLoop(MotorPWM_t *m, uint8_t n, float sp, float *u_rep);
static void PID_Step(PID_t *pid, float setpoint, float rpm_actual,
                     MotorPWM_t *m, uint8_t n, float *u_rep);
static void EncHealth_Update(volatile EncHealth_t *h, int32_t cnt_total,
                             float sp, float vel, float u, PID_t *pid);
static void CAN_SendEncoders(void);
static void CAN_Filter_Config(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

static inline float f_abs(float x) { return (x < 0.0f) ? -x : x; }

static void PID_Init(void)
{
    q0 =  Kp * (1.0f + DT / (2.0f * Ti) + Td / DT);
    q1 = -Kp * (1.0f - DT / (2.0f * Ti) + 2.0f * Td / DT);
    q2 =  Kp * Td / DT;
}

static void PID_Reset(PID_t *pid)
{
    pid->e0 = pid->e1 = pid->e2 = 0.0f;
    pid->u = pid->u_ant = 0.0f;
}

static void ApplyPWM(MotorPWM_t *m, uint8_t n, float u)
{
    if (u >= 0.0f) {
        uint32_t v = (uint32_t)u;
        for (uint8_t i = 0; i < n; i++) {
            __HAL_TIM_SET_COMPARE(m[i].htim, m[i].ch_fwd, v);
            __HAL_TIM_SET_COMPARE(m[i].htim, m[i].ch_rev, 0);
        }
    } else {
        uint32_t v = (uint32_t)(-u);
        for (uint8_t i = 0; i < n; i++) {
            __HAL_TIM_SET_COMPARE(m[i].htim, m[i].ch_fwd, 0);
            __HAL_TIM_SET_COMPARE(m[i].htim, m[i].ch_rev, v);
        }
    }
}

/* ══════════════════════════════════════════════════════════════════════
 *  FRENO ACTIVO (plugging) — requiere encoder sano
 * ══════════════════════════════════════════════════════════════════════
 *  Par en CONTRA de la velocidad medida. Es la diferencia entre "dejar de
 *  acelerar" (PWM 0 = rueda libre) y "detenerse".
 *  Se autoapaga al bajar de BRAKE_EPS_RPM, así que no rebota hacia reversa
 *  ni se queda vibrando. Se le pasa velFilt, no la velocidad cruda: el
 *  ruido del encoder haría saltar el PWM entre extremos.                  */
static void ApplyBrake(MotorPWM_t *m, uint8_t n, float rpm_med, float *u_rep)
{
    if (f_abs(rpm_med) < BRAKE_EPS_RPM) {   /* ya detenida: suelta el par */
        ApplyPWM(m, n, 0.0f);
        *u_rep = 0.0f;
        return;
    }

    float u = -BRAKE_GAIN * rpm_med;
    if (u >  1000.0f) u =  1000.0f;
    if (u < -1000.0f) u = -1000.0f;
    ApplyPWM(m, n, u);
    *u_rep = u;
}

/* ══════════════════════════════════════════════════════════════════════
 *  ★ FRENO SIN ENCODER  —  el agujero que tapa el punto ★3
 * ══════════════════════════════════════════════════════════════════════
 *  Con el encoder muerto, ApplyBrake() lee velocidad 0, cree que la rueda
 *  ya está detenida y SUELTA EL PAR: rueda libre. El paro de emergencia no
 *  frenaba ese lado.
 *
 *  Aquí se aplica par en contra del ÚLTIMO SETPOINT conocido, a duty fijo,
 *  durante un tiempo ACOTADO. Lo del tiempo acotado es lo importante: sin
 *  realimentación no hay forma de saber cuándo la rueda se detuvo, y un par
 *  en contra indefinido acabaría girándola en reversa.
 *
 *  No es un freno fino, pero detiene. Que es de lo que se trata.           */
static void ApplyBrakeOpenLoop(volatile EncHealth_t *h, MotorPWM_t *m,
                               uint8_t n, float *u_rep)
{
    if (h->brake_ticks == 0 || h->last_sp == 0.0f) {
        ApplyPWM(m, n, 0.0f);
        *u_rep = 0.0f;
        return;
    }

    h->brake_ticks--;
    float u = (h->last_sp > 0.0f) ? -BRAKE_OL_DUTY : BRAKE_OL_DUTY;
    ApplyPWM(m, n, u);
    *u_rep = u;
}

/* ══════════════════════════════════════════════════════════════════════
 *  ★ LAZO ABIERTO — control degradado
 * ══════════════════════════════════════════════════════════════════════
 *  u = FF_OFFSET·signo(sp) + FF_GAIN·sp, con tope al 60%.
 *  Sin encoder no hay corrección posible: la velocidad real dependerá de la
 *  carga, la pendiente y la batería. Es aproximado por naturaleza, y por eso
 *  se limita: un lado sin vigilancia no debe correr a fondo.               */
static void ApplyOpenLoop(MotorPWM_t *m, uint8_t n, float sp, float *u_rep)
{
    float u = 0.0f;
    if (sp >  0.01f) u =  1000.0f;
    else if (sp < -0.01f) u = -1000.0f;

    ApplyPWM(m, n, u);
    *u_rep = u;
}

static void PID_Step(PID_t *pid, float setpoint, float rpm_actual,
                     MotorPWM_t *m, uint8_t n, float *u_rep)
{
    pid->e0 = setpoint - rpm_actual;
    float delta_u = q0 * pid->e0 + q1 * pid->e1 + q2 * pid->e2;
    pid->u = delta_u + pid->u_ant;

    /* Clamp CON anti-windup: al copiar u (ya acotada) a u_ant, el término
     * acumulado no puede crecer más allá del tope. */
    if (pid->u >  1000.0f) pid->u =  1000.0f;
    if (pid->u < -1000.0f) pid->u = -1000.0f;

    ApplyPWM(m, n, pid->u);
    *u_rep = pid->u;

    pid->e2 = pid->e1;
    pid->e1 = pid->e0;
    pid->u_ant = pid->u;
}

/* ══════════════════════════════════════════════════════════════════════
 *  ★ VIGILANCIA DEL ENCODER
 * ══════════════════════════════════════════════════════════════════════
 *  Se llama una vez por lado por ciclo, ANTES de decidir el control.
 *
 *  Síntoma A (muerto):   se pide movimiento + el PID empuja fuerte +
 *                        los conteos no cambian.
 *  Síntoma B (invertido): la velocidad medida tiene signo opuesto a u con
 *                        |u| alto = realimentación positiva.
 *
 *  Ambos exigen DEG_FAULT_TICKS seguidos: un glitch aislado no degrada.
 *  Para volver a lazo cerrado se exigen DEG_OK_TICKS de lecturas sanas y
 *  se resetea el PID, para que el reenganche no dé un tirón.               */
static void EncHealth_Update(volatile EncHealth_t *h, int32_t cnt_total,
                             float sp, float vel, float u, PID_t *pid)
{
    /* Recordar la última dirección comandada: la usa el freno sin encoder. */
    if (f_abs(sp) > 0.01f) h->last_sp = sp;

    uint8_t counts_moving = (cnt_total != h->last_cnt);
    h->last_cnt = cnt_total;

    uint8_t cmd_moving = (f_abs(sp) > DEG_SP_MIN_RPM);
    uint8_t u_high     = (f_abs(u)  > DEG_U_FAULT);

    /* A: empuja fuerte y el contador no se mueve */
    uint8_t sym_dead = (cmd_moving && u_high && !counts_moving);

    /* B: signo de vel opuesto al de u, con velocidad creíble */
    uint8_t sym_inv  = (u_high && (f_abs(vel) > DEG_VEL_MIN_RPM) &&
                        ((u > 0.0f && vel < 0.0f) || (u < 0.0f && vel > 0.0f)));

    if (!h->degraded)
    {
        if (sym_dead || sym_inv) {
            if (++h->fault_ticks >= DEG_FAULT_TICKS) {
                h->degraded    = 1;
                h->fault_ticks = 0;
                h->ok_ticks    = 0;
                PID_Reset(pid);          /* mata el integrador acumulado */
            }
        } else {
            h->fault_ticks = 0;
        }
    }
    else
    {
        /* Para recuperar: que el contador se mueva mientras se comanda algo.
         * Si no se está pidiendo movimiento no se puede saber si el encoder
         * revivió, así que el contador de recuperación no avanza. */
        if (cmd_moving && counts_moving) {
            if (++h->ok_ticks >= DEG_OK_TICKS) {
                h->degraded = 0;
                h->ok_ticks = 0;
                PID_Reset(pid);          /* reenganche limpio, sin tirón */
            }
        } else if (cmd_moving) {
            h->ok_ticks = 0;
        }
    }
}

/* Callback TIM5 — cada periodo de control */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM5) {
        flag_tim5 = 1;
    }
}

/* Lee un int16 little-endian del buffer CAN. */
static inline int16_t rd_i16(const uint8_t *b)
{
    return (int16_t)((uint16_t)b[0] | ((uint16_t)b[1] << 8));
}

/* ==== CAN RX de comandos ====
 * 0x300: setpoint_L/R (int16 x100 RPM) y un byte 4 opcional con el modo.
 * Actualizar setpoints y patear el watchdog es lo que hacía el UART antes. */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &can_rx_header, can_rx_data) != HAL_OK)
        return;

    if (can_rx_header.StdId == CAN_ID_CMD)
    {
        /* Compatibilidad: una comms que aún mande DLC 4 se interpreta NORMAL. */
        uint8_t mode = (can_rx_header.DLC >= 5) ? can_rx_data[4] : CMD_MODE_NORMAL;

        if (mode == CMD_MODE_BRAKE)
        {
            brake_request = 1;
            setpoint_L = 0.0f;
            setpoint_R = 0.0f;
        }
        else
        {
            brake_request = 0;
            setpoint_L = (float)rd_i16(&can_rx_data[0]) / 100.0f;
            setpoint_R = (float)rd_i16(&can_rx_data[2]) / 100.0f;
        }

        rx_watchdog = 0;   /* comando fresco: resetea el failsafe */
    }
}

/* Filtro CAN: acepta solo 0x300. Con máscara exacta evitamos que las tramas
 * de la IMU (0x100+) o las propias de encoder ocupen la FIFO. */
static void CAN_Filter_Config(void)
{
    CAN_FilterTypeDef filter;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = (CAN_ID_CMD << 5);
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = (0x7FF << 5);
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14;
    HAL_CAN_ConfigFilter(&hcan1, &filter);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_CAN1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM8_Init();
  MX_TIM5_Init();

  /* USER CODE BEGIN 2 */

  CAN_Filter_Config();
  HAL_CAN_Start(&hcan1);
  HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

  /* Encoders (ambos 16 bits) */
  HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);   // encoder IZQ
  HAL_TIM_Encoder_Start(&htim8, TIM_CHANNEL_ALL);   // encoder DER

  /* Base de control */
  HAL_TIM_Base_Start_IT(&htim5);

  /* PWM — LADO DERECHO */
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);

  /* PWM — LADO IZQUIERDO */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  /* Enables: drivers atados HIGH por hardware. PC0/PC1 en SET por compat. */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_SET);

  PID_Init();

  /* Arranca FRENADO, no en rueda libre: si el rover se enciende en una
   * pendiente no debe rodar solo mientras espera el primer comando. */
  brake_request = 1;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      if (flag_tim5)
      {
          /* Encoder IZQ (TIM4, 16 bits) */
          uint16_t cnt_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim4);
          int16_t dL    = -(int16_t)(cnt_L - cnt_prev_L);
          cnt_prev_L     = cnt_L;

          /* Encoder DER (TIM8, 16 bits) */
          uint16_t cnt_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim8);
          int16_t dR    = (int16_t)(cnt_R - cnt_prev_R);
          cnt_prev_R     = cnt_R;

          cnt_total_L += (int32_t)dL;
          cnt_total_R += (int32_t)dR;

          vel_L     = ((float)dL * 60.0f) / (PPR * DT);
          velFilt_L = 0.23f * vel_L + 0.77f * velFilt_L;
          pos_L    += ((float)dL / PPR) * 360.0f;

          vel_R     = ((float)dR * 60.0f) / (PPR * DT);
          velFilt_R = 0.23f * vel_R + 0.77f * velFilt_R;
          pos_R    += ((float)dR / PPR) * 360.0f;

          t += DT;

          /* ══════════════════════════════════════════════════════════════
           *  ★ SALUD DE LOS ENCODERS
           * ══════════════════════════════════════════════════════════════
           *  Va ANTES del control: la decisión de este ciclo ya usa el
           *  estado actualizado. Se le pasa la u REALMENTE aplicada en el
           *  ciclo anterior, no pid.u, para que la detección funcione
           *  también viniendo de una rama de freno o de lazo abierto. */
          EncHealth_Update(&health_L, cnt_total_L, setpoint_L, velFilt_L,
                           u_out_L, &pid_L);
          EncHealth_Update(&health_R, cnt_total_R, setpoint_R, velFilt_R,
                           u_out_R, &pid_R);

          /* ══════════════════════════════════════════════════════════════
           *  FAILSAFE
           * ══════════════════════════════════════════════════════════════
           *  Sin trama 0x300 reciente (~0.46 s) el rover FRENA, no queda en
           *  rueda libre. Cubre el caso peor: se cayó el WiFi, la Jetson, el
           *  rosbridge o el navegador, y el rover iba a toda velocidad.
           *  Esta rama es la única protección que no depende de nada remoto. */
          if (rx_watchdog < CMD_TIMEOUT_TICKS) {
              rx_watchdog++;
          } else {
              setpoint_L    = 0.0f;
              setpoint_R    = 0.0f;
              brake_request = 1;
          }

          /* ══════════════════════════════════════════════════════════════
           *  CONTROL — frenar y perseguir setpoint son EXCLUYENTES
           * ══════════════════════════════════════════════════════════════ */
          uint8_t was_braking = braking_now;
          braking_now = brake_request;

          /* Al ENTRAR al freno se arma la ventana del freno en lazo abierto,
           * para el lado que no tiene encoder. */
          if (braking_now && !was_braking) {
              health_L.brake_ticks = BRAKE_OL_TICKS;
              health_R.brake_ticks = BRAKE_OL_TICKS;
          }

          if (braking_now)
          {
              /* Reset del PID en cada ciclo de freno: al soltar el paro el
               * integrador arranca limpio y no da un tirón. */
              PID_Reset(&pid_L);
              PID_Reset(&pid_R);

              /* ★ Cada lado frena con lo que tenga. Con encoder: plugging
               * proporcional. Sin encoder: duty fijo acotado en tiempo.
               * Antes, el lado degradado simplemente NO FRENABA. */
              if (health_L.degraded)
                  ApplyBrakeOpenLoop(&health_L, motors_L, N_MOT_PER_SIDE, (float*)&u_out_L);
              else
                  ApplyBrake(motors_L, N_MOT_PER_SIDE, velFilt_L, (float*)&u_out_L);

              if (health_R.degraded)
                  ApplyBrakeOpenLoop(&health_R, motors_R, N_MOT_PER_SIDE, (float*)&u_out_R);
              else
                  ApplyBrake(motors_R, N_MOT_PER_SIDE, velFilt_R, (float*)&u_out_R);
          }
          else
          {
              /* ★ Lado por lado: uno puede ir en lazo cerrado y el otro en
               * abierto sin problema. El rover sigue manejable con un solo
               * encoder vivo. */
              if (health_L.degraded)
                  ApplyOpenLoop(motors_L, N_MOT_PER_SIDE, setpoint_L, (float*)&u_out_L);
              else
                  PID_Step(&pid_L, setpoint_L, velFilt_L, motors_L,
                           N_MOT_PER_SIDE, (float*)&u_out_L);

              if (health_R.degraded)
                  ApplyOpenLoop(motors_R, N_MOT_PER_SIDE, setpoint_R, (float*)&u_out_R);
              else
                  PID_Step(&pid_R, setpoint_R, velFilt_R, motors_R,
                           N_MOT_PER_SIDE, (float*)&u_out_R);
          }

          /* Telemetría por CAN hacia la comms (no bloquea el lazo).
           * Va DESPUÉS del control para reportar la u realmente aplicada. */
          CAN_SendEncoders();

          /* LED de vida: parpadeo lento = normal. Si se queda fijo, el lazo
           * de control se colgó. */
          static uint8_t led_cnt = 0;
          if (++led_cnt >= 50) { HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin); led_cnt = 0; }

          flag_tim5 = 0;
      }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* ==== CAN TX de encoders (telemetria) ==== */
static inline int16_t clamp_i16(float v)
{
    if (v >  32767.0f) return  32767;
    if (v < -32768.0f) return -32768;
    return (int16_t)v;
}

static void can_put_i16(uint8_t *buf, int16_t val)
{
    buf[0] = (uint8_t)(val & 0xFF);           /* little-endian */
    buf[1] = (uint8_t)((val >> 8) & 0xFF);
}

static void can_put_i32(uint8_t *buf, int32_t val)
{
    buf[0] = (uint8_t)(val & 0xFF);           /* little-endian */
    buf[1] = (uint8_t)((val >> 8)  & 0xFF);
    buf[2] = (uint8_t)((val >> 16) & 0xFF);
    buf[3] = (uint8_t)((val >> 24) & 0xFF);
}

static void CAN_SendEncoders(void)
{
    uint8_t data[8];

    can_tx_header.IDE = CAN_ID_STD;
    can_tx_header.RTR = CAN_RTR_DATA;
    can_tx_header.TransmitGlobalTime = DISABLE;

    /* 0x200: conteos crudos acumulados */
    can_tx_header.StdId = 0x200;
    can_tx_header.DLC   = 8;
    can_put_i32(&data[0], cnt_total_L);
    can_put_i32(&data[4], cnt_total_R);
    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0)
        HAL_CAN_AddTxMessage(&hcan1, &can_tx_header, data, &can_tx_mailbox);

    /* 0x201: velocidades filtradas + setpoints (RPM x100) */
    can_tx_header.StdId = 0x201;
    can_tx_header.DLC   = 8;
    can_put_i16(&data[0], clamp_i16(velFilt_L  * 100.0f));
    can_put_i16(&data[2], clamp_i16(velFilt_R  * 100.0f));
    can_put_i16(&data[4], clamp_i16(setpoint_L * 100.0f));
    can_put_i16(&data[6], clamp_i16(setpoint_R * 100.0f));
    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0)
        HAL_CAN_AddTxMessage(&hcan1, &can_tx_header, data, &can_tx_mailbox);

    /* 0x202: salida del control + flags.
     * ★ CAMBIO: se reporta u_out (lo aplicado de verdad al PWM), no pid.u.
     * Antes, durante el freno pid.u valía 0 y la telemetría mentía sobre el
     * par que se estaba aplicando; en degradado habría hecho lo mismo.
     *
     * FLAGS (byte 4):
     *    bit0 = frenando
     *    bit1 = IZQUIERDO degradado (sin encoder)
     *    bit2 = DERECHO degradado
     * La comms lee solo los primeros 4 bytes, así que esto no rompe nada.
     * Para verlo en la UI hay que propagarlo desde la comms — pero OJO:
     * NO agregando un campo al CSV de encoders, porque el bridge discrimina
     * los streams por número de campos (9 = encoders, 10 = IMU) y un décimo
     * campo haría que lo parseara como IMU. Va en una línea aparte. */
    can_tx_header.StdId = 0x202;
    can_tx_header.DLC   = 5;
    can_put_i16(&data[0], clamp_i16(u_out_L));
    can_put_i16(&data[2], clamp_i16(u_out_R));
    data[4] = (uint8_t)((braking_now        ? 0x01 : 0x00) |
                        (health_L.degraded  ? 0x02 : 0x00) |
                        (health_R.degraded  ? 0x04 : 0x00));
    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0)
        HAL_CAN_AddTxMessage(&hcan1, &can_tx_header, data, &can_tx_mailbox);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/*
 * ══════════════════════════════════════════════════════════════════════════
 *  PRUEBAS — TODAS CON LAS RUEDAS AL AIRE y el corte de corriente a la mano
 * ══════════════════════════════════════════════════════════════════════════
 *
 *  Observa /wheel_debug desde la Jetson mientras pruebas.
 *
 *  ── P1. NO ROMPIMOS NADA (regresión) ────────────────────────────────────
 *     Con AMBOS encoders sanos, manda SP:20,20 y confirma que las dos
 *     velocidades siguen al setpoint y las dos u se estabilizan.
 *     Si esto no pasa, para: el modo degradado no es el problema.
 *
 *  ── P2. DEGRADACIÓN (la prueba principal) ───────────────────────────────
 *     Con SP:20,20 corriendo y todo estable, DESCONECTA el cable del
 *     encoder derecho en caliente.
 *
 *     ESPERADO en ~300 ms:
 *        · La rueda derecha NO se dispara a fondo. Se queda girando a una
 *          velocidad parecida (lazo abierto con feedforward).
 *        · u_R deja de subir y se queda en ~FF_GAIN·20 = 396.
 *        · vel_R reporta 0 (el encoder está muerto, es correcto).
 *
 *     FALLA: si u_R se va a 1000 y la rueda se acelera al máximo, la
 *     detección no disparó. Revisa que DEG_U_FAULT (800) sea alcanzable
 *     con tus ganancias.
 *
 *     Esto es exactamente lo que pasaba en julio y lo que hay que evitar en
 *     competencia: una rueda a fondo sin control.
 *
 *  ── P3. RECUPERACIÓN ────────────────────────────────────────────────────
 *     Reconecta el encoder derecho con el SP todavía corriendo.
 *     ESPERADO: en ~200 ms vuelve a lazo cerrado, vel_R vuelve a reportar y
 *     u_R se reajusta SIN un tirón brusco (por el PID_Reset).
 *
 *  ── P4. FRENO CON UN ENCODER MUERTO  ★ la que tapa el agujero nuevo ─────
 *     Desconecta el encoder derecho, avanza con SP:25,25, y suelta el
 *     comando (Ctrl+C) para que entre el failsafe — o manda SP:BRAKE.
 *
 *     ESPERADO: AMBAS ruedas frenan. La izquierda por plugging
 *     proporcional, la derecha por el duty fijo de ~0.5 s.
 *
 *     ANTES DE ESTE CAMBIO la derecha quedaba en RUEDA LIBRE y seguía
 *     girando por inercia. Si al probar ves eso, ApplyBrakeOpenLoop no se
 *     está invocando.
 *
 *  ── P5. ENCODER INVERTIDO ───────────────────────────────────────────────
 *     Difícil de provocar sin recablear. Si alguna vez ves que un lado se
 *     degrada solo estando el encoder conectado, revisa el signo del delta
 *     de ESE lado (dL lleva '-', dR no). El modo degradado te está
 *     protegiendo de una realimentación positiva, pero es un error de
 *     cableado que hay que corregir, no una función.
 *
 *  ── P6. CALIBRAR FF_GAIN ────────────────────────────────────────────────
 *     Ver la nota del encabezado. Hazlo ANTES de confiar en el modo
 *     degradado: con un FF_GAIN mal calibrado el rover se moverá, pero a
 *     una velocidad bastante distinta de la que pidas.
 *
 *  ── DESPUÉS ─────────────────────────────────────────────────────────────
 *  Solo cuando P1 a P4 pasen, baja el rover al suelo. Y guarda el .bin de
 *  esta versión antes de tocar nada más.
 * ══════════════════════════════════════════════════════════════════════════
 */
