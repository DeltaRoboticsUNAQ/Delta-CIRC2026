/* bno085_hal_spi.h */
#ifndef BNO085_HAL_SPI_H
#define BNO085_HAL_SPI_H

#include "sh2_hal.h"

/* Retorna el puntero a la estructura HAL para pasarla a sh2_open() */
sh2_Hal_t* BNO085_GetHal(void);

#endif /* BNO085_HAL_SPI_H */
