/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : STM32 IMU (BNO085) -> CSV por UART + CAN TX a la comms
  *                   *** VERSION CON DIAGNOSTICO DE CAN ***
  *
  * CAN TX (500 kbps, PA12=TX / PB8=RX):
  *   0x100 : qw,qx,qy,qz  (int16 x16384)  -> 8 bytes
  *   0x101 : gx,gy,gz     (int16 x1000)   -> 6 bytes
  *   0x102 : ax,ay,az     (int16 x1000)   -> 6 bytes
  *
  * ══════════ COMO LEER EL DIAGNOSTICO ══════════
  * Cada 2 s sale:
  *   CAN TEC=0 REC=0 ESR=0x0 free=3 try=1234 ok=1234 fail=0 BOFF=0 EPVF=0 EWGF=0
  *
  *   TEC   = Transmit Error Counter. Es EL dato clave.
  *   REC   = Receive Error Counter.
  *   ESR   = registro de error crudo.
  *   free  = buzones de TX libres (3 = todos vacios).
  *   try   = veces que se INTENTO mandar una trama.
  *   ok    = veces que AddTxMessage acepto la trama (la encolo).
  *   fail  = veces que AddTxMessage fallo.
  *   BOFF  = 1 -> BUS OFF (se rindio; con AutoBusOff=DISABLE NO se recupera solo)
  *   EPVF  = 1 -> Error Passive (TEC>127)
  *   EWGF  = 1 -> Error Warning (TEC>95)
  *
  * INTERPRETACION:
  *   TEC=128 fijo, EPVF=1  -> transmite pero NADIE le hace ACK. Su
  *                            transceptor funciona; el problema esta entre
  *                            las placas o en el transceptor de la comms.
  *   BOFF=1                -> bus-off. Se rindio. Revisa cableado y resetea.
  *   TEC sube rapidisimo   -> error de BIT: manda dominante pero no lo ve
  *                            reflejado -> casi siempre el pin Rs del
  *                            SN65HVD230 flotando (modo standby = mudo).
  *                            Rs DEBE ir a GND.
  *   TEC=0, try sube, ok=try, free=3 siempre
  *                         -> las tramas se van limpias y alguien las ACKea.
  *                            El bus esta BIEN: el problema es de la comms.
  *   try=0                 -> no se esta llamando CAN_SendIMU (data_ready).
  *
  * NOTA CLOCK: PLLN=180, PLLR=2 y SYSCLKSource=PLLRCLK -> 360/2 = 180 MHz.
  * APB1 = 180/4 = 45 MHz -> Prescaler=6 con BS1=12/BS2=2 da 500 kbps. OK.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
#include "sh2.h"
#include "sh2_SensorValue.h"
#include "bno085_hal_spi.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* Pon en 0 para apagar el diagnostico cuando ya funcione todo.
 * OJO: con DEBUG_CAN=1 el CSV de 10 campos sigue saliendo igual; las lineas
 * de debug las descarta solo el bridge de ROS2 (no tienen 10 campos). */
#define DEBUG_CAN   1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static sh2_SensorValue_t sensor_value;
static volatile uint8_t  data_ready = 0;
static volatile uint8_t  do_config  = 0;

/* Ultimos valores recibidos del BNO085.
 * Los tres reportes (GRV, giroscopio, acelerometro) llegan como eventos
 * SEPARADOS, asi que cada uno actualiza sus propias variables. Imprimimos
 * cuando llega un rotation vector nuevo, usando los valores mas recientes
 * de giro y aceleracion disponibles. */
static volatile float q_w = 1.0f, q_x = 0.0f, q_y = 0.0f, q_z = 0.0f;

/* NUEVO: giroscopio calibrado (rad/s) -> Imu.angular_velocity para el EKF */
static volatile float gyro_x = 0.0f, gyro_y = 0.0f, gyro_z = 0.0f;

/* NUEVO: acelerometro completo (m/s^2). Antes solo guardabamos Z;
 * el EKF (robot_localization) usa los tres ejes. */
static volatile float accel_x = 0.0f, accel_y = 0.0f, accel_z = 0.0f;

/* ---- CAN TX (agregado, corre en paralelo al UART) ----
 * Esta STM solo transmite; los mismos datos que ya salen por el CSV del UART
 * se mandan tambien por CAN a la STM de comunicaciones. */
static CAN_TxHeaderTypeDef can_tx_header;
static uint32_t            can_tx_mailbox;

/* ---- DIAGNOSTICO ---- */
static volatile uint32_t dbg_tx_try  = 0;   /* intentos de envio */
static volatile uint32_t dbg_tx_ok   = 0;   /* AddTxMessage OK */
static volatile uint32_t dbg_tx_fail = 0;   /* AddTxMessage fallo */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static void sensor_event_handler(void *cookie, sh2_SensorEvent_t *pEvent);
static void async_event_handler(void *cookie, sh2_AsyncEvent_t *pEvent);
static void CAN_SendIMU(void);   /* NUEVO */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART2_UART_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */

  /* Arrancar CAN. Solo TX: no configuramos filtro de aceptacion porque esta
   * STM no recibe nada del bus. HAL_CAN_Start es obligatorio antes de mandar. */
  if (HAL_CAN_Start(&hcan1) != HAL_OK)
  {
      printf("ERROR: HAL_CAN_Start fallo!\r\n");
  }
  else
  {
      printf("CAN1 arrancado (TX 500 kbps, PA12/PB8)\r\n");
  }

#if DEBUG_CAN
  /* Reloj real, para confirmar que el bit timing es el correcto.
   * HCLK debe decir 180000000 y PCLK1 45000000. */
  printf("HCLK=%lu PCLK1=%lu (esperado 180000000 / 45000000)\r\n",
         (unsigned long)HAL_RCC_GetHCLKFreq(),
         (unsigned long)HAL_RCC_GetPCLK1Freq());
#endif

  /* Esperar que todo el hardware este estable despues de reset */
  HAL_Delay(500);
  printf("Iniciando BNO085...\r\n");

  sh2_Hal_t *hal = BNO085_GetHal();

  int rc = sh2_open(hal, async_event_handler, NULL);
  printf("sh2_open rc = %d\r\n", rc);

  if (rc != 0)
  {
      printf("ERROR: sh2_open fallo!\r\n");
      while (1)
      {
          HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
          HAL_Delay(100);
      }
  }

  sh2_setSensorCallback(sensor_event_handler, NULL);

  sh2_devReset();
  printf("devReset enviado\r\n");
  HAL_Delay(500);

  printf("Listo, entrando al loop...\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  sh2_service();

	  if (do_config)
	  {
	      do_config = 0;
	      printf("Configurando reportes...\r\n");

	      sh2_SensorConfig_t config;
	      memset(&config, 0, sizeof(config));
	      config.reportInterval_us = 10000;  /* 10 ms -> 100 Hz */

	      /* Reporte 1: orientacion (cuaternion, sin magnetometro) */
	      int rc_grv = sh2_setSensorConfig(SH2_GAME_ROTATION_VECTOR, &config);
	      printf("setSensorConfig GRV rc = %d\r\n", rc_grv);

	      /* NUEVO - Reporte 2: giroscopio calibrado (rad/s).
	       * Lo consume el EKF de robot_localization como angular_velocity. */
	      int rc_gyr = sh2_setSensorConfig(SH2_GYROSCOPE_CALIBRATED, &config);
	      printf("setSensorConfig GYRO rc = %d\r\n", rc_gyr);

	      /* Reporte 3: acelerometro (az para vibracion + 3 ejes para EKF) */
	      int rc_acc = sh2_setSensorConfig(SH2_ACCELEROMETER, &config);
	      printf("setSensorConfig ACCEL rc = %d\r\n", rc_acc);

	      /* Dar tiempo al sensor para procesar los comandos
	       * y llamar sh2_service varias veces seguidas */
	      HAL_Delay(50);
	      for (int i = 0; i < 100; i++)
	      {
	          sh2_service();
	          HAL_Delay(1);
	      }
	      printf("Post-config service done\r\n");
	  }

	  if (data_ready)
	  {
	      data_ready = 0;

	      /* Salida CSV para el bridge ROS2 (formato extendido, 10 campos).
	       * Orden: qw,qx,qy,qz,gx,gy,gz,ax,ay,az
	       *   - qw,qx,qy,qz -> Imu.orientation (w,x,y,z)
	       *   - gx,gy,gz    -> Imu.angular_velocity (rad/s)
	       *   - ax,ay,az    -> Imu.linear_acceleration (m/s^2)
	       * az sigue alimentando el factor de vibracion del controlador. */
	      printf("%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f\r\n",
	             q_w, q_x, q_y, q_z,
	             gyro_x, gyro_y, gyro_z,
	             accel_x, accel_y, accel_z);

	      /* NUEVO: el mismo dato del CSV, ahora tambien por CAN hacia la
	       * STM de comunicaciones. No bloquea el loop (ver CAN_SendIMU). */
	      CAN_SendIMU();
	  }

	  /* ── Debug cada 2 segundos ── */
	  static uint32_t last_dbg = 0;
	  if (HAL_GetTick() - last_dbg >= 2000)
	  {
	      last_dbg = HAL_GetTick();
	      uint8_t int_pin = HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin);

#if DEBUG_CAN
	      uint32_t esr = CAN1->ESR;
	      printf("CAN TEC=%lu REC=%lu ESR=0x%lX free=%lu try=%lu ok=%lu fail=%lu "
	             "BOFF=%lu EPVF=%lu EWGF=%lu LEC=%lu INT=%d\r\n",
	             (unsigned long)((esr >> 16) & 0xFF),          /* TEC */
	             (unsigned long)((esr >> 24) & 0xFF),          /* REC */
	             (unsigned long)esr,
	             (unsigned long)HAL_CAN_GetTxMailboxesFreeLevel(&hcan1),
	             (unsigned long)dbg_tx_try,
	             (unsigned long)dbg_tx_ok,
	             (unsigned long)dbg_tx_fail,
	             (unsigned long)((esr >> 2) & 0x1),            /* BOFF */
	             (unsigned long)((esr >> 1) & 0x1),            /* EPVF */
	             (unsigned long)(esr & 0x1),                   /* EWGF */
	             (unsigned long)((esr >> 4) & 0x7),            /* LEC */
	             int_pin);
#else
	      printf("INT=%d data_ready=%d\r\n", int_pin, data_ready);
#endif
	  }

	  HAL_Delay(1);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLRCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

static void async_event_handler(void *cookie, sh2_AsyncEvent_t *pEvent)
{
	printf("ASYNC event id=%lu\r\n", pEvent->eventId);
    if (pEvent->eventId == 0)  /* 0 = reset event */
    {
        do_config = 1;
    }
}

static void sensor_event_handler(void *cookie, sh2_SensorEvent_t *pEvent)
{
    int rc = sh2_decodeSensorEvent(&sensor_value, pEvent);
    if (rc != 0)
    {
        return;
    }

    switch (sensor_value.sensorId)
    {
        case SH2_GAME_ROTATION_VECTOR:
            q_w = sensor_value.un.gameRotationVector.real;
            q_x = sensor_value.un.gameRotationVector.i;
            q_y = sensor_value.un.gameRotationVector.j;
            q_z = sensor_value.un.gameRotationVector.k;
            /* El rotation vector dispara la impresion; adjunta los valores
             * mas recientes de giro y aceleracion */
            data_ready = 1;
            break;

        /* NUEVO: giroscopio calibrado en rad/s (convencion REP-103 de ROS) */
        case SH2_GYROSCOPE_CALIBRATED:
            gyro_x = sensor_value.un.gyroscope.x;
            gyro_y = sensor_value.un.gyroscope.y;
            gyro_z = sensor_value.un.gyroscope.z;
            break;

        case SH2_ACCELEROMETER:
            /* NUEVO: ahora guardamos los 3 ejes, no solo Z */
            accel_x = sensor_value.un.accelerometer.x;
            accel_y = sensor_value.un.accelerometer.y;
            accel_z = sensor_value.un.accelerometer.z;
            break;

        default:
            break;
    }
}

/* ==== CAN: envio de datos IMU ====================================
 * Los 10 valores del CSV no caben en una trama clasica (8 bytes max), asi que
 * van en 3 tramas como int16 escalados. La STM de comunicaciones invierte la
 * escala (float = int16 / escala) para reconstruir el CSV hacia la Jetson.
 *
 *   0x100 : qw,qx,qy,qz  (x16384, rango [-1,1])   -> 8 bytes
 *   0x101 : gx,gy,gz     (x1000, milli-rad/s)     -> 6 bytes
 *   0x102 : ax,ay,az     (x1000, milli-m/s^2)     -> 6 bytes
 *
 * Cada valor se guarda little-endian (byte bajo primero).
 * ================================================================ */
static inline int16_t clamp_i16(float v)
{
    if (v >  32767.0f) return  32767;
    if (v < -32768.0f) return -32768;
    return (int16_t)v;
}

static void can_put_i16(uint8_t *buf, int16_t val)
{
    buf[0] = (uint8_t)(val & 0xFF);          /* little-endian */
    buf[1] = (uint8_t)((val >> 8) & 0xFF);
}

/* Encola una trama y contabiliza el resultado (para el diagnostico). */
static void can_try_send(uint8_t *data)
{
    dbg_tx_try++;
    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan1) > 0)
    {
        if (HAL_CAN_AddTxMessage(&hcan1, &can_tx_header, data, &can_tx_mailbox) == HAL_OK)
            dbg_tx_ok++;
        else
            dbg_tx_fail++;
    }
    else
    {
        /* Sin buzon libre: las tramas anteriores NO han salido del chip.
         * Sintoma clasico de que nadie hace ACK en el bus. */
        dbg_tx_fail++;
    }
}

static void CAN_SendIMU(void)
{
    uint8_t data[8];

    can_tx_header.IDE = CAN_ID_STD;
    can_tx_header.RTR = CAN_RTR_DATA;
    can_tx_header.TransmitGlobalTime = DISABLE;

    /* 0x100: cuaternion */
    can_tx_header.StdId = 0x100;
    can_tx_header.DLC   = 8;
    can_put_i16(&data[0], clamp_i16(q_w * 16384.0f));
    can_put_i16(&data[2], clamp_i16(q_x * 16384.0f));
    can_put_i16(&data[4], clamp_i16(q_y * 16384.0f));
    can_put_i16(&data[6], clamp_i16(q_z * 16384.0f));
    can_try_send(data);

    /* 0x101: giroscopio (rad/s -> milli-rad/s) */
    can_tx_header.StdId = 0x101;
    can_tx_header.DLC   = 6;
    can_put_i16(&data[0], clamp_i16(gyro_x * 1000.0f));
    can_put_i16(&data[2], clamp_i16(gyro_y * 1000.0f));
    can_put_i16(&data[4], clamp_i16(gyro_z * 1000.0f));
    can_try_send(data);

    /* 0x102: acelerometro (m/s^2 -> milli-m/s^2) */
    can_tx_header.StdId = 0x102;
    can_tx_header.DLC   = 6;
    can_put_i16(&data[0], clamp_i16(accel_x * 1000.0f));
    can_put_i16(&data[2], clamp_i16(accel_y * 1000.0f));
    can_put_i16(&data[4], clamp_i16(accel_z * 1000.0f));
    can_try_send(data);
}

int uart2_write(int ch)
{
    while(!(USART2->SR & USART_SR_TXE)){}
    USART2->DR = (ch & 0xFF);
    return ch;
}

int __io_putchar(int ch)
{
    uart2_write(ch);
    return ch;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
