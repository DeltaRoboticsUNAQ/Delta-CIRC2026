/* bno085_hal_spi.c */
#include "bno085_hal_spi.h"
#include "main.h"
#include "spi.h"
#include <string.h>

extern SPI_HandleTypeDef hspi2;

#define BNO085_MAX_PACKET 1024

static int spi_open(sh2_Hal_t *self)
{
    HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);

    /* Reset completo del BNO085 */
    HAL_GPIO_WritePin(BNO085_RST_GPIO_Port, BNO085_RST_Pin, GPIO_PIN_RESET);
    HAL_Delay(100);  /* mantener reset más tiempo */
    HAL_GPIO_WritePin(BNO085_RST_GPIO_Port, BNO085_RST_Pin, GPIO_PIN_SET);
    HAL_Delay(300);  /* esperar que el firmware arranque completamente */

    /* Esperar que INT baje con timeout de 3 segundos */
    uint32_t t0 = HAL_GetTick();
    while (HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin) == GPIO_PIN_SET)
    {
        if (HAL_GetTick() - t0 > 3000)
        {
            return -1;
        }
    }

    return 0;
}

static void spi_close(sh2_Hal_t *self)
{
}

static int spi_read(sh2_Hal_t *self,
                    uint8_t   *pBuffer,
                    unsigned   len,
                    uint32_t  *t_us)
{
    if (HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin) == GPIO_PIN_SET)
    {
        return 0;
    }

    uint8_t header[4] = {0};
    HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_RESET);
    HAL_Delay(1);

    if (HAL_SPI_Receive(&hspi2, header, 4, 100) != HAL_OK)
    {
        HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);
        return -1;
    }

    uint16_t packet_len = (uint16_t)(header[0] | (header[1] << 8));
    packet_len &= ~0x8000u;

    if (packet_len == 0 || packet_len > len || packet_len > BNO085_MAX_PACKET)
    {
        HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);
        return 0;
    }

    memcpy(pBuffer, header, 4);

    if (packet_len > 4)
    {
        if (HAL_SPI_Receive(&hspi2, pBuffer + 4, packet_len - 4, 100) != HAL_OK)
        {
            HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);
            return -1;
        }
    }

    HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);
    *t_us = HAL_GetTick() * 1000;

    return (int)packet_len;
}

static int spi_write(sh2_Hal_t *self,
                     uint8_t   *pBuffer,
                     unsigned   len)
{
    /* Esperar que INT esté en alto antes de escribir */
    uint32_t t0 = HAL_GetTick();
    while (HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin) == GPIO_PIN_RESET)
    {
        if (HAL_GetTick() - t0 > 100)
        {
            break;
        }
    }

    HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_StatusTypeDef status = HAL_SPI_Transmit(&hspi2, pBuffer, len, 100);
    HAL_GPIO_WritePin(BNO085_CS_GPIO_Port, BNO085_CS_Pin, GPIO_PIN_SET);

    /* Esperar que INT baje indicando que el sensor procesó el comando */
    t0 = HAL_GetTick();
    while (HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin) == GPIO_PIN_SET)
    {
        if (HAL_GetTick() - t0 > 500)
        {
            printf("spi_write: timeout esperando INT bajo\r\n");
            return (status == HAL_OK) ? (int)len : -1;
        }
    }

    printf("spi_write: INT bajo, sensor proceso comando\r\n");
    return (status == HAL_OK) ? (int)len : -1;
}

static uint32_t spi_getTimeUs(sh2_Hal_t *self)
{
    return HAL_GetTick() * 1000;
}

static sh2_Hal_t bno085_hal = {
    .open      = spi_open,
    .close     = spi_close,
    .read      = spi_read,
    .write     = spi_write,
    .getTimeUs = spi_getTimeUs,
};

sh2_Hal_t* BNO085_GetHal(void)
{
    return &bno085_hal;
}
