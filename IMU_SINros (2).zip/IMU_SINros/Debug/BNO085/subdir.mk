################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/BNO085/bno085_hal_spi.c \
../Drivers/BNO085/euler.c \
../Drivers/BNO085/sh2.c \
../Drivers/BNO085/sh2_SensorValue.c \
../Drivers/BNO085/sh2_util.c \
../Drivers/BNO085/shtp.c 

OBJS += \
./BNO085/bno085_hal_spi.o \
./BNO085/euler.o \
./BNO085/sh2.o \
./BNO085/sh2_SensorValue.o \
./BNO085/sh2_util.o \
./BNO085/shtp.o 

C_DEPS += \
./BNO085/bno085_hal_spi.d \
./BNO085/euler.d \
./BNO085/sh2.d \
./BNO085/sh2_SensorValue.d \
./BNO085/sh2_util.d \
./BNO085/shtp.d 


# Each subdirectory must supply rules for building sources it contributes
BNO085/bno085_hal_spi.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/bno085_hal_spi.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
BNO085/euler.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/euler.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
BNO085/sh2.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/sh2.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
BNO085/sh2_SensorValue.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/sh2_SensorValue.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
BNO085/sh2_util.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/sh2_util.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
BNO085/shtp.o: C:/st_proyects/IMU_SINros/Drivers/BNO085/shtp.c BNO085/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/BNO085 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-BNO085

clean-BNO085:
	-$(RM) ./BNO085/bno085_hal_spi.cyclo ./BNO085/bno085_hal_spi.d ./BNO085/bno085_hal_spi.o ./BNO085/bno085_hal_spi.su ./BNO085/euler.cyclo ./BNO085/euler.d ./BNO085/euler.o ./BNO085/euler.su ./BNO085/sh2.cyclo ./BNO085/sh2.d ./BNO085/sh2.o ./BNO085/sh2.su ./BNO085/sh2_SensorValue.cyclo ./BNO085/sh2_SensorValue.d ./BNO085/sh2_SensorValue.o ./BNO085/sh2_SensorValue.su ./BNO085/sh2_util.cyclo ./BNO085/sh2_util.d ./BNO085/sh2_util.o ./BNO085/sh2_util.su ./BNO085/shtp.cyclo ./BNO085/shtp.d ./BNO085/shtp.o ./BNO085/shtp.su

.PHONY: clean-BNO085

